import csv, io, json, os, sys, encodings.utf_8_sig
from pathlib import Path
from decimal import Decimal, localcontext

root = Path.cwd().resolve()
allowed = {root / n for n in ('main.py','input.csv','output.csv','summary.csv')}
def audit(event, args):
    if event.startswith('socket.') or event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn'):
        raise PermissionError('network and subprocesses forbidden')
    if event == 'open' and not isinstance(args[0], int):
        if Path(os.fsdecode(args[0])).resolve() not in allowed:
            raise PermissionError('only frozen local artifacts allowed')
sys.addaudithook(audit)
mask = int(sys.argv[1])
if not 0 <= mask <= 7: raise ValueError('unregistered mask')
raw = Path('input.csv').read_bytes()
if len(raw) > 1048576: raise ValueError('input too large')
table = list(csv.reader(io.StringIO(raw.decode('utf-8-sig'),newline=''),strict=True))
if not table or table[0] != ['sample_id','subject_id','split','group','value']:
    raise ValueError('schema mismatch')
rows = table[1:]
if len(rows) > 5000 or any(len(r) != 5 for r in rows): raise ValueError('invalid rows')
if mask & 1:
    seen = set(); kept = []
    for r in rows:
        if r[0] not in seen: kept.append(r); seen.add(r[0])
    rows = kept
if mask & 2:
    splits = {}
    for r in rows: splits.setdefault(r[1],set()).add(r[2])
    rows = [r for r in rows if len(splits[r[1]]) == 1]
if mask & 4: rows = [r for r in rows if r[4].strip()]
with Path('output.csv').open('w',encoding='utf-8',newline='') as f:
    w = csv.writer(f); w.writerow(table[0]); w.writerows(rows)
groups = {}
for r in rows:
    if r[2] != 'test': continue
    groups.setdefault(r[3],[]).append(r[4])
if not groups: raise ValueError('no test records')
out = []
with localcontext() as ctx:
    ctx.prec = 40
    for group, values in sorted(groups.items()):
        numeric = [Decimal(v.strip()) for v in values if v.strip()]
        if not numeric or any(not v.is_finite() or abs(v) > Decimal('1e12') for v in numeric):
            raise ValueError('no finite numeric values for group')
        total = sum(numeric,Decimal(0))
        out.append([group,str(len(values)),str(len(numeric)),str(total),str(total/len(numeric))])
with Path('summary.csv').open('w',encoding='utf-8',newline='') as f:
    w = csv.writer(f); w.writerow(['group','n_rows','n_numeric','sum','mean']); w.writerows(out)
print(json.dumps({'mask':mask,'rows':len(rows),'groups':len(out)}))
